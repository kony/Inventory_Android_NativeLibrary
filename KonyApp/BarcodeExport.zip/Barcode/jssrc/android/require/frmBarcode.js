define("frmBarcode", function() {
    return function(controller) {
        function addWidgetsfrmBarcode() {
            this.setDefaultUnit(kony.flex.DP);
            var barcodescanner = new com.konymp.barcodescanner({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "barcodescanner",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "70dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "59.30%"
            }, {}, {});
            barcodescanner.btnText = "Scan Barcode/QRCode";
            barcodescanner.afterScan = controller.AS_UWI_c04561824b134c5395fad826d36e5a5c;
            var Label0ic4303c6a15a48 = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "Label0ic4303c6a15a48",
                "isVisible": true,
                "left": "120dp",
                "skin": "lblskn",
                "text": "Scan Product Name...",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "top": "258dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            this.add(barcodescanner, Label0ic4303c6a15a48);
        };
        return [{
            "addWidgets": addWidgetsfrmBarcode,
            "enabledForIdleTimeout": false,
            "id": "frmBarcode",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_e7a0c415216c409a985fdc9f649e8ca8,
            "skin": "slForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});