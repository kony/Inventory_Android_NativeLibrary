define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** afterScan defined for barcodescanner **/
    AS_UWI_c04561824b134c5395fad826d36e5a5c: function AS_UWI_c04561824b134c5395fad826d36e5a5c(scannedData) {
        var self = this;
        var resultData = {
            scanData: scannedData
        };
        kony.application.sendLibraryResultToNativeApp(resultData);
        kony.application.exitLibrary();
    },
    /** postShow defined for frmBarcode **/
    AS_Form_e7a0c415216c409a985fdc9f649e8ca8: function AS_Form_e7a0c415216c409a985fdc9f649e8ca8(eventobject) {
        var self = this;
        this.view.barcodescanner.scanCode();
    }
});