define(function() {
    return {
        "properties": [{
            "name": "scanSkin",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "btnText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "scanFocusSkin",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["scanCode"],
        "events": ["afterScan"]
    }
});