/**
* Created by Team Kony.
* Copyright (c) 2017 Kony Inc. All rights reserved.
**/
define(function () {
	var konymp = konymp || {};
	var KonyLoggerModule = require("com/konymp/barcodescanner/KonyLogger");
	konymp.logger = (new KonyLoggerModule("Barcode Scanner Component")) || function () {};
	return {
		constructor: function (baseConfig, layoutConfig, pspConfig) {
			this._deviceInfo=kony.os.deviceInfo().name;
          
             if(this._deviceInfo === 'android'){
            self = null;
			this.BarcodeCaptureActivity = java.import('com.google.android.gms.samples.vision.barcodereader.BarcodeCaptureActivity');
			this.BarcodeCaptureWrapper = java.import('com.google.android.gms.samples.vision.barcodereader.BarcodeCaptureWrapper');
			this.Barcode = java.import("com.google.android.gms.vision.barcode.Barcode");
			this.INTENT = java.import("android.content.Intent");
			this.ACTIVITY = java.import("android.app.Activity");
			this.PACKAGE_MANAGER = java.import("android.content.pm.PackageManager");
			this.REQUEST_CODE = 9001;
			this.context = null;
          }
		},
		//Logic for getters/setters of custom properties
		initGettersSetters: function () {},
		afterScan: function () {},
		permissionStatusCallback: function (response) {
			try {
				konymp.logger.trace("----------------------------- Start  permissionStatusCallback", konymp.logger.FUNCTION_ENTRY);
				if (response.status == kony.application.PERMISSION_GRANTED) {
					this.scanBarcodeAndroid();
				} else if (response.status == kony.application.PERMISSION_DENIED) {
					return;
				}
				konymp.logger.trace("----------------------------- End permissionStatusCallback", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},

		scanCode: function () {
			try {
				konymp.logger.trace("----------------------------- Start  scanCode", konymp.logger.FUNCTION_ENTRY);
			if(this._deviceInfo==='android'){
              var options = {
					isAccessModeAlways: true
				};
				var result = kony.application.checkPermission(kony.os.RESOURCE_CAMERA, options);
				if (result.status == kony.application.PERMISSION_DENIED) {

					var optionCam = {
						isVideoCapture: true
					};
					kony.application.requestPermission(kony.os.RESOURCE_CAMERA, this.permissionStatusCallback.bind(this), optionCam);

				} else if (result.status == kony.application.PERMISSION_GRANTED) {
					this.scanBarcodeAndroid();
				}
            }
				else if(this._deviceInfo==='iPhone'){
				this.scanBarcodeiOS();
                }
				konymp.logger.trace("----------------------------- End scanCode", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},
		scanBarcodeAndroid: function () {
			try {
				konymp.logger.trace("----------------------------- Start  scanBarcodeAndroid", konymp.logger.FUNCTION_ENTRY);
				this.startScanAndroidSecond();
				self = this;
				konymp.logger.trace("----------------------------- End scanBarcodeAndroid", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},
		startScanAndroidSecond: function () {
			try {
				konymp.logger.trace("----------------------------- Start  startScanAndroidSecond", konymp.logger.FUNCTION_ENTRY);
				var MainClass = java.newClass("MainClass", "java.lang.Object", ["com.konylabs.ffi.ActivityResultListener"], {
						onActivityResult: function (requestCode, resultCode, intent) {
                          if (resultCode == 16){
                           	kony.print("Cancelled button Clicked")
                          }
                          else if (resultCode == 0){
							var barcode = intent.getParcelableExtra("Barcode");
							this.afterScan(barcode.displayValue);}
						}
						.bind(this)
					});
				var intentClassObj = new MainClass();
				var KonyMain = java.import('com.konylabs.android.KonyMain');
				this.context = KonyMain.getActivityContext();
				this.context.registerActivityResultListener(this.REQUEST_CODE, intentClassObj);
				this.initiateScanSecond();
				konymp.logger.trace("----------------------------- End startScanAndroidSecond", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},

		initiateScanSecond: function () {
			try {
				konymp.logger.trace("----------------------------- Start  initiateScanSecond", konymp.logger.FUNCTION_ENTRY);
				KonyMain = java.import('com.konylabs.android.KonyMain');
				var obj = this.BarcodeCaptureWrapper();
				obj.startBarcodeActivity(KonyMain.getActivityContext());
				konymp.logger.trace("----------------------------- End initiateScanSecond", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},
		scanBarcodeiOS: function () {
			try {
				konymp.logger.trace("----------------------------- Start  scanBarcodeiOS", konymp.logger.FUNCTION_ENTRY);
				var KonyBarcodeScan = objc.import("Scanner");
				var konyBarcodeScan = KonyBarcodeScan.alloc().jsinit();
				konyBarcodeScan.StartBarcodeScanning(this.callback.bind(this));
				konymp.logger.trace("----------------------------- End scanBarcodeiOS", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},
		callback: function (scannedDatd) {
			try {
				konymp.logger.trace("----------------------------- Start  callback", konymp.logger.FUNCTION_ENTRY);
				this.afterScan(scannedDatd);
				konymp.logger.trace("----------------------------- End callback", konymp.logger.FUNCTION_EXIT);
			} catch (e) {
				konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
			}
		},
	};
});