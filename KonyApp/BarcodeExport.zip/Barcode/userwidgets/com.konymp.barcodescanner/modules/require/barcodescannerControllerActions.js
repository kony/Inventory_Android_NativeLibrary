define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnScan **/
    AS_Button_e73ecd1a2790455785f8f29bcdc0ab97: function AS_Button_e73ecd1a2790455785f8f29bcdc0ab97(eventobject) {
        var self = this;
        return self.scanCode.call(this);
    }
});