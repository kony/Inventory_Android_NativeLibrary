define(function() {
    return function(controller) {
        var barcodescanner = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "8%",
            "id": "barcodescanner",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "59.30%"
        }, {}, {});
        barcodescanner.setDefaultUnit(kony.flex.DP);
        var btnScan = new kony.ui.Button({
            "focusSkin": "konympBsBtnScan",
            "height": "100%",
            "id": "btnScan",
            "isVisible": true,
            "left": "0dp",
            "onClick": controller.AS_Button_e73ecd1a2790455785f8f29bcdc0ab97,
            "skin": "konympBsBtnScan",
            "text": "Scan Barcode/QRCode",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        barcodescanner.add(btnScan);
        return barcodescanner;
    }
})